Trio para macOS | Aplicativo gratuito / Free app / App gratuita

Português
Leia INSTALLATION.md. Install.command copia o app para Aplicativos e conserva
a versão anterior. A primeira abertura pode exigir aprovação normal do macOS.
O pacote contém Apple Silicon e Intel; hardware Intel ainda não foi testado.
Aplicativo gratuito. Código-fonte, versão atual e histórico:
https://github.com/Benfic4rthur/Trio

English
Read INSTALLATION.md. Install.command copies the app to Applications and keeps
the previous version. macOS may require its normal first-open approval.
The package contains Apple Silicon and Intel code; Intel hardware is untested.
Free app. Source code, current version and release history:
https://github.com/Benfic4rthur/Trio

Español
Lee INSTALLATION.md. Install.command copia la app a Aplicaciones y conserva
la versión anterior. macOS puede solicitar su autorización normal al abrirla.
Incluye código para Apple Silicon e Intel; no se ha probado hardware Intel.
App gratuita. Código fuente, versión actual e historial:
https://github.com/Benfic4rthur/Trio
